% File:    hard_constraint_2.pro
% Author:  Isha Afzaal (30016250)
% Course:  CPSC 449 - Winter 2019 - Assignment #3 - Prolog
% Date:    April 2, 2019
% Info:    Given a list of solutions, enforce the second hard constraint (forbidden machine: any assignment that assigns
%		     a given task t to the indicated machine m is invalid). Create a new list of solutions that only includes solutions that pass 
%		     the forbidden machine criteria (i.e. create new solutions list by process of elimination).

% --- Clauses: ---

% Goal of Hard Constraint 2: For a given solution, the goal succeeds if and only if the assignment does not contain any given forbidden pair
hard_constraint_2_goal([], _).
hard_constraint_2_goal([[Mach | Task] | RestOfPairs], CandidateSolution) :-
   nth1(Mach, CandidateSolution, Elem),
   Task \= [Elem],
   hard_constraint_2_goal(RestOfPairs, CandidateSolution).


% --- Caller ---
hard_constraint_2_apply(SolutionList, ForbiddenList, TheResult) :-
   include(hard_constraint_2_goal(ForbiddenList), SolutionList, TheResult).