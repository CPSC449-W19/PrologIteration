% File:    brute_force.pro
% Author:  Isha Afzaal (30016250)
% Course:  CPSC 449 - Winter 2019 - Assignment #3 - Prolog
% Date:    April 10, 2019
% Info:    Using brute force, narrow down and determine the best machine-task assignment for the given
%	        penalty lists (enforce hard constraints 1 - 3 and soft constraints 1 - 2).
% Usage:   Suppose parser.pro wants to use brute_force.pro to compute the solution for a given machine-task problem:
%             - Ensure that parser.pro is within the same directory as brute_force.pro, permutations.pro, hard_constraint_1.pro, etc.
%             - Call brute_force_apply(Forced, Forbidden, TooNear, Machines, TooNearPens, TheTrueSolution), where the solution, if there is one, will
%               be stored in TheTrueSolution (if there is no solution, TheTrueSolution = []), otherwise the first 8 elements of TheTrueSolution
%               will be the machine-task assignments, while the ninth element will be the designated penalty value

% --- Load Required Files ---
:- [permutations, hard_constraint_1, hard_constraint_2, hard_constraint_3, soft_constraint_1, soft_constraint_2].


% --- Clauses ---
brute_force_check_if_empty([]).

% Find the solution with the least penalty value
brute_force_find_min([], _, _).
brute_force_find_min([CandidateSolution | RestOfSolutions], AllPossibleSolutions, MinimumSolution) :-
   confirm_minimum(CandidateSolution, AllPossibleSolutions) -> MinimumSolution = CandidateSolution;
   brute_force_find_min(RestOfSolutions, AllPossibleSolutions, MinimumSolution).

% Compare the given solution to every single solution in the filtered solution list
confirm_minimum(_, []).
confirm_minimum(SuspectSolution, [CurrentCheck | RestOfChecks]) :-
   nth1(9, SuspectSolution, SuspectPenalty),
   nth1(9, CurrentCheck, CurrentPenalty),
   ( (SuspectPenalty = CurrentPenalty) ; (SuspectPenalty < CurrentPenalty) ),
   confirm_minimum(SuspectSolution, RestOfChecks).


% --- Driver ---
brute_force_apply(Forced, Forbidden, TooNear, Machines, TooNearPens, TheTrueSolution) :-
   permutations_init(MasterList),
   hard_constraint_1_apply(MasterList, Forced, InterResult1),
   hard_constraint_2_apply(InterResult1, Forbidden, InterResult2),
   hard_constraint_3_apply(InterResult2, TooNear, InterResult3),
   machine_penalty_apply(InterResult3, Machines, InterResult4),
   too_near_penalty_apply(InterResult4, TooNearPens, FilteredList),
   (brute_force_check_if_empty(FilteredList) -> TheTrueSolution = [];
   brute_force_find_min(FilteredList, FilteredList, TheTrueSolution) ).