% File:    main.pro
% Author:  Isha Afzaal (30016250)
% Course:  CPSC 449 - Winter 2019 - Assignment #3 - Prolog
% Date:    April 10, 2019
% Info:    Demonstrate how to use brute_force.pro within any file that wants to use its functionality.
% Usage:
%          Compile with 
%				        swipl --goal=main -o main -c main.pro
%		   Run with 
%						./main

% Load brute force
:- [brute_force].

format_solution_output([], FileName) :-
   open(FileName, write, Out),
   write(Out, "No valid solution possible!"),
   close(Out).

format_solution_output([Task1, Task2, Task3, Task4, Task5, Task6, Task7, Task8, PenaltyValue], FileName) :-
   open(FileName, write, Out),
   write(Out, "Solution "),
   write(Out, Task1), write(Out, " "),
   write(Out, Task2), write(Out, " "),
   write(Out, Task3), write(Out, " "),
   write(Out, Task4), write(Out, " "),
   write(Out, Task5), write(Out, " "),
   write(Out, Task6), write(Out, " "),
   write(Out, Task7), write(Out, " "),
   write(Out, Task8),
   write(Out, "; Quality: "), write(Out, PenaltyValue),
   close(Out).

main :-
   % --- Fill these parameters in with parser, for now I have dummy values ---
   FileName = 'out.txt',
   Forced = [[1,'A'],[2,'B'], [3,'C'], [4,'D'], [5,'E']],
   Forbidden = [[6,'F'],[7,'G']],
   TooNear = [['F','G']],
   Machines=[[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1] ],
   TooNearPens = [['F','H',30]],
   % --- End of Parameters List ---
   % --- Call brute_force like this ---
   brute_force_apply(Forced, Forbidden, TooNear, Machines, TooNearPens, TheTrueSolution),
   % --- Format the solution and print to output file ---
   format_solution_output(TheTrueSolution, FileName),
   halt.
