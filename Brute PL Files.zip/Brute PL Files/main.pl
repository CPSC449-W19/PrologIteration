% Contains how to use brute force code

% Load brute force
:- [brute_force].

main :-
   Forced = [[1,'A'],[2,'B'], [3,'C'], [4,'D'], [5,'E']],
   Forbidden = [[6,'F'],[7,'G']],
   TooNear = [['F','G']],
   Machines=[[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1],[1,1,1,1,1,1,1,1] ],
   TooNearPens = [['F','H',30]],
   brute_force_apply(Forced, Forbidden, TooNear, Machines, TooNearPens, TheTrueSolution),
   write(TheTrueSolution), nl,
   halt.
