% File:    hard_constraint_1.pl
% Author:  Isha Afzaal (30016250)
% Course:  CPSC 449 - Winter 2019 - Assignment #3 - Prolog
% Date:    April 2, 2019
% Info:    Given a list of solutions, enforce the first hard constraint (forced partial assignment: any assignment that does not assign 
%		     a given task t to the indicated machine m is invalid). Create a new list of solutions that only includes solutions that pass 
%		     the forced partial assignment criteria (i.e. create new solutions list by process of elimination).

% --- Clauses: ---

% Goal of Hard Constraint 1: For a given solution, the goal succeeds if and only if the assignment contains all given pairs in forced partial
hard_constraint_1_goal([], _).
hard_constraint_1_goal([[Mach | Task] | RestOfPairs], CandidateSolution) :-
   nth1(Mach, CandidateSolution, Elem),
   Task = [Elem],
   hard_constraint_1_goal(RestOfPairs, CandidateSolution).


% --- Caller ---
hard_constraint_1_apply(SolutionList, ForcedList, TheResult) :-
   include(hard_constraint_1_goal(ForcedList), SolutionList, TheResult).