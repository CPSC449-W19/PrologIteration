% File:    permutations.pl
% Author:  Isha Afzaal (30016250)
% Course:  CPSC 449 - Winter 2019 - Assignment #3 - Prolog
% Date:    April 2, 2019
% Info:    Find all possible permutation combinations and store them within a list of lists

% --- Clauses ---
permutations_getter(GivenList, Xs) :-
   bagof(X, permutation(GivenList, X), Xs).

% --- Caller ---
% permutations_init generates all possible solutions
permutations_init(TheSolutions) :-
   DefaultList = ['A','B','C','D','E','F','G','H'],
   permutations_getter(DefaultList, TheSolutions).